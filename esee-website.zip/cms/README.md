# blank

blank

## Attributes

- **Database**: mongodb
- **Storage Adapter**: localDisk
